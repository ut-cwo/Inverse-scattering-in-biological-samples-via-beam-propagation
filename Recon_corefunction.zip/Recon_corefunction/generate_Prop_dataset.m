%%
% This function implements the forward model, as defined by the multi-slice beam propagation method.
%
% inputs:   acqs:           electric field measurement at imaging plane
%           fx_in:          horizontal component of illumination wave-vector
%           fy_in:          vertical component of illumination wave-vector
%           dfx:            Fourier spacing
%           prop_phs:       phase term of propagation kernel
%           psz:            pixel size (z) in reconstructed object space(micron)
%           FocalPlane      Refocusing distance from imaging plane
%           xx:             2D grid of x-coordinates
%           yy:             2D grid of y-coordinates
%           pdar:           padding used on the object
%
%
%
% outputs:
%           Prop_dataser:   refocused field measurement
%
% Author: Jeongsoo Kim & Shwetadwip Chowdhury; Aug 16, 2025

function Prop_dataset = generate_Prop_dataset(acqs, fx_in, fy_in, dfx, prop_phs, psz, FocalPlane, xx, yy, pdar)

% Pad raw measurements
amp_acqs_pad = padarray(acqs, [pdar, pdar, 0],1);

clear acqs

% Preallocate memory
[Nx, Ny, Nz] = size(amp_acqs_pad);
num_planes   = length(FocalPlane);
Prop_dataset = single(zeros(Nx, Ny, Nz, num_planes));
temp_dataset = zeros(Nx, Ny, Nz);

for idx = 1:length(FocalPlane)

    i = FocalPlane(idx);

    % Compute propagation kernel
    if i > 0
        prop_kernel = conj(exp(prop_phs * psz * i));
    else
        prop_kernel = exp(prop_phs * psz * -i);
    end

    % Loop over all measurements
    for ii = 1:Nz
        fx_in_interp = fix(fx_in(ii)/dfx) * dfx;
        fy_in_interp = fix(fy_in(ii)/dfx) * dfx;
        U_in = exp(1i * 2 * pi * (fx_in_interp * xx + fy_in_interp * yy));

        temp1 = fft2(amp_acqs_pad(:,:,ii) .* U_in);
        temp2 = ifft2(temp1 .* prop_kernel);
        temp3 = ifft2(fft2(U_in) .* prop_kernel);

        temp_dataset(:,:,ii) = temp2 ./ temp3;
    end

    Prop_dataset(:,:,:,idx) = single(temp_dataset);
end

clear amp_acqs_pad temp_dataset

% Rearrange and crop padding
Prop_dataset = permute(Prop_dataset, [1, 2, 4, 3]);
Prop_dataset = Prop_dataset((pdar+1):(end-pdar), (pdar+1):(end-pdar), :, :);

end
