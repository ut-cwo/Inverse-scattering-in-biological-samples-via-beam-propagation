%%
% This file demonstrates the Rytov 3D reconstruction method for
% reconstructing 3D refractive-index from a set of electric-field
% measurements captured of an object by illuminating at different angles.
% Each angled illumination results in carrying object information that lies
% on an Ewald surface in the object's 3D Fourier space into the
% measurements. These information components are aggregated together and
% appropriately repositioned into 3D Fourier space. The 3D object is
% subsequently reconstructed. This reconstructed 3D RI volume serves as the
% initial guess for subsequent MSBP reconstruction.
%
% Author: Jeongsoo Kim & Shwetadwip Chowdhury; Aug 16, 2025
%
% NOTE:
% this code is only beta-tested. The user is encouraged to go 
% block-by-block in this code .M file to confirm that code works as intended.
%
% On a Windows computer, 'cntrl'+'enter' runs a specific block at a time%
%
% reference:
% Yongjin Sung, Wonshik Choi, Christopher Fang-Yen, Kamran Badizadegan, 
% Ramachandra R. Dasari, and Michael S. Feld, "Optical diffraction 
% tomography for high resolution live cell imaging," Opt. Express 17, 
% 266-277 (2009)

function [reconObj] = Rytov_recon_init(Efield_amplitude_crop,Efield_phase_crop,n_imm,ps,psz,O,lambda,NA,fx_illum_ref,fy_illum_ref,pdar)


%% load Efield measurements

Efield_amplitude    = Efield_amplitude_crop;
Efield_phase        = Efield_phase_crop;

%% Setting spatial and frequency axes for original hologram image
N                   = single(size(Efield_phase,1)); % lateral pixel dimension of object
x                   = single(ps*[-N/2:N/2-1]);      % 1D padded axis in x
[xx,yy]             = meshgrid(x,x);                % 2D padded grid in x/y

dfx                 = single(1/(N*ps));             % Fourier spacing of axis
fx                  = single(dfx*[-N/2:N/2-1]);     % 1D padded axis in fx
[fxx,fyy]           = meshgrid(fx,fx);              % 2D padded grid in fx/fy
f0                  = 1/lambda;
fzz                 = real(sqrt((n_imm*f0)^2-fxx.^2-fyy.^2));

%% Initializes 3D volume within which the scattering potential's 3D content will be reconstructed
Recon_Rytov_fft         = single(zeros(1*N,1*N,1*N));
count                   = single(zeros(1*N,1*N,1*N));

%% Sets a mask to bound Fourier content to be within the NA/lambda diffraction limit
mskDC                              = logical(ones(size(fxx)));
mskDC(fxx.^2+fyy.^2<(NA/lambda)^2) = 0;

%%

tic;
for k = 1:size(Efield_phase,3)

    % extracts amplitude and unwrapped field component from the loaded dataset

    amplitude               = Efield_amplitude(:,:,k);
    phase                   = Efield_phase(:,:,k);
    
    % linearizes the complex exponential field measurement by using Rytov
    % approximation
    Efield_Rytov            = log(amplitude)+1j*phase;

    % takes the Fourier transform
    Efield_Rytov_fft        = fft2_DC(Efield_Rytov)./(length(Efield_Rytov(:)).*dfx^2);

    % shifts the Fourier transform by the illumination beam's 2D lateral
    % wavevector component
    Efield_Rytov_fft        = subPixelShift(Efield_Rytov_fft,-fy_illum_ref(k)/dfx,-fx_illum_ref(k)/dfx);
    Efield_Rytov_fft(mskDC) = 0;
    fzz(mskDC)              = 0;

    % shifts the frequency axes by the illumination beam's 2D lateral
    % wavevector component
    fx_shft                 = fx-fx_illum_ref(k);
    fy_shft                 = fx-fy_illum_ref(k);
    [fxx_shft, fyy_shft]    = meshgrid(fx_shft,fy_shft);

    % calculates axial wavevector component and shifts it accordingly
    fz_illum                = sqrt((n_imm*f0).^2-fx_illum_ref(k).^2-fy_illum_ref(k).^2);
    fzz_shft                = fzz-fz_illum;

    % calculates the 2D scattered field according to the Fourier
    % Diffraction Theorem. This 2D field will be mapped into 3D
    sct_field_fft           = 1j*2*(2*pi)*(fzz) .* Efield_Rytov_fft;

    % finds index of all points that will be projected into 3D. This index
    % is then used to locate all points within the scattered field and axes
    % distributions
    linIndx                     = fzz>0;
    lin_sct_field_fft           = sct_field_fft(linIndx);
    lin_fxx_shft                = fxx_shft(linIndx);
    lin_fyy_shft                = fyy_shft(linIndx);
    lin_fzz_shft                = fzz_shft(linIndx);

    % calculates the I,J,K indices in which each point from the 2D
    % measurement needs to be projected in 3D
    I_indx                  = round(lin_fyy_shft/dfx+size(Recon_Rytov_fft,1)/2)+1;
    J_indx                  = round(lin_fxx_shft/dfx+size(Recon_Rytov_fft,2)/2)+1;
    K_indx                  = round(lin_fzz_shft/dfx+size(Recon_Rytov_fft,3)/2)+1;

    % linearizes the I,J,K indices into just one index
    indx                    = sub2ind(size(Recon_Rytov_fft),I_indx,J_indx,K_indx);

    % transfers scattered-field information into space located for it in
    % the 3D volume
    count(indx)             = count(indx)+1;
    Recon_Rytov_fft(indx)   = Recon_Rytov_fft(indx)+lin_sct_field_fft;

    disp(['processing complete for Efield measurement: ' num2str(k)]);
end
toc;
%% normalize the 3D Fourier Transform and then inverse FFT to retrieve sample's scattering potential
Recon_Rytov_fft_normalized              = Recon_Rytov_fft;
Recon_Rytov_fft_normalized(count>0)     = Recon_Rytov_fft_normalized(count>0)./count(count>0);
scat_potential                          = ifftn_DC(Recon_Rytov_fft_normalized)./ps^3;

%% reconstructs 3D refractive index from scattering potential and 3D visualizes it from the xy and xz cross sections
Recon_RI                                = real(n_imm*sqrt(1-scat_potential.*(lambda/(n_imm*2*pi))^2));

%% Perform resizing to align with the input dimensions required for MSBP reconstruction
Nz = size(Recon_RI, 3);
Nz_target = round(O * psz / ps);

if Nz_target > Nz
    pad_total = double(Nz_target - Nz);
    pad_front = floor(pad_total/2);
    pad_back  = ceil(pad_total/2);

    Recon_RI = padarray(Recon_RI, [0,0,pad_front], n_imm, 'pre');
    Recon_RI = padarray(Recon_RI, [0,0,pad_back],  n_imm, 'post');
end

center_z = round(size(Recon_RI,3)/2);

Recon_RI = Recon_RI(:,:,center_z - round(Nz_target/2)+1 : center_z + round(Nz_target/2));
reconObj = imresize3(Recon_RI, [size(Efield_amplitude,1), size(Efield_amplitude,2), O]) - n_imm;
reconObj = padarray(reconObj, [pdar, pdar, 0]);

%% Applying non-negativity constraint
Positive_mask           = reconObj<0;
reconObj(Positive_mask) = 0;
end