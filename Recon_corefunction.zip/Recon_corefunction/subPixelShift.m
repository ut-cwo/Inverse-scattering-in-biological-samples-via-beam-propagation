function im_shft = subPixelShift(im,deltar,deltac )
%subPixelShift subpixel shifts an image im by deltar and deltac, in pixels!

[nr,nc]=size(im);
Nr = ifftshift((-fix(nr/2):ceil(nr/2)-1));
Nc = ifftshift((-fix(nc/2):ceil(nc/2)-1));
[Nc,Nr] = meshgrid(Nc,Nr);
im_shft = ifft2(fft2(im).*exp(1i*2*pi*(deltar*Nr/nr+deltac*Nc/nc)));

end

