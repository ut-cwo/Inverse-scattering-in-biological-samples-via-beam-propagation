%%
% This function implements the back-projection gradient update component
% of the multi-slice beam propagation method.
%
% inputs:   obj:            3D matrix of \delta RI values
%           psz:            pixel size (z) in reconstructed object space(micron)
%           efield:         electric-field measurement simulated output from a Forward model
%           efield_vol:     layer-specific electric-fields, also output from a Forward model
%           amp_acqs:       amplitude measurements detected by imaging system
%           prop_phs:       phase term of propagation kernel
%           NA_crop:        pupil support
%           lambda:         imaging wavelength
%           z_plane:        center plane of reconstruction volume, where 0 um is object volume center
%           step_size:      step size for gradient-based optimization protocol
%           pdar:           padding used on the object
%           use_field:      TRUE: uses field-component for reconstruction
%                           FALSE: uses amplitude-only component for reconstruction
%           U_in            Phase compensation for field-based reconstruction
%           use_gpu         True: compute on GPU
%                           False: compute on CPU
%           Prop_datset     refocused amplitude data
%           efield_prop     refocsed MSBP forward model results
%           Focus_range     Refocusing distance
%           OF              obliquity factor
%
% outputs:
%           obj:            object after gradient-update iteration
%           cost_value:     cost value
%
% Author: Jeongsoo Kim & Shwetadwip Chowdhury; Aug 16, 2025
% Thank you to Michael Chen and David Ren, for preliminary
% versions of this code
%
% reference:
% S. Chowdhury, M. Chen, R. Eckert, D. Ren, F. Wu, N. Repina, and L.
% Waller, "High-resolution 3D refractive index microscopy of multiple-
% scattering samples from intensity images," Optica 6, 1211-1219 (2019)

function [obj,cost_value] = BPM_update(obj, psz, efield, efield_vol, prop_phs, NA_crop, lambda, z_plane, step_size, pdar, use_field,U_in,use_gpu,Prop_dataset,efield_prop,Focus_range,OF)
% compute residual

back_prop_temp = single(zeros(size(efield_prop,1),size(efield_prop,2),size(efield_prop,3)));
Prop_dataset   = gpuArray(Prop_dataset);

for i = 1:size(Prop_dataset,3)

    if use_field
        Prop_dataset_temp = Prop_dataset(:,:,i);
        Prop_dataset_temp = Prop_dataset_temp.*U_in(:,:,i);
        back_prop_temp(:,:,i)     = efield_prop(:,:,i) - (Prop_dataset_temp);
    else
        back_prop_temp(:,:,i)     = efield_prop(:,:,i) - abs(Prop_dataset(:,:,i)).* exp(1i*angle(efield_prop(:,:,i)));
    end

end

% compute cost
res               = abs(efield_prop(:,:,round(end/2))) - abs(Prop_dataset(:,:,round(end/2)));
cost_value        = norm(res(:))^2;


back_prop_temp    = padarray(back_prop_temp,[pdar,pdar,0]);
back_prop         = single(zeros(size(back_prop_temp,1),size(back_prop_temp,2),size(back_prop_temp,3)));

count = 1;



for i = Focus_range

    if i>0
        prop_kernel  = (exp(prop_phs * psz * i));
    else
        prop_kernel  = conj(exp(prop_phs * psz * -i));
    end

    back_prop(:,:,count) = ifft2(fft2(back_prop_temp(:,:,count)).*prop_kernel);
    count = count+1;

end

%% compute gradient
back_prop(efield==0)    = 0;


% back-propagation to volume center
for zIdx = 1:length(z_plane)

    if z_plane(zIdx)<0
        prop_kernel             = exp(1.* -z_plane(zIdx) .* prop_phs);
    else
        prop_kernel             = conj(exp(1.* z_plane(zIdx) .* prop_phs));
    end

    prop_kernel(NA_crop)    = 0;
    
    for k = 1:length(Focus_range)
    back_prop(:,:,k)     = prop_kernel.* fft2(back_prop(:,:,k));
    end
end

% propagation to the last slice
prop_kernel             = exp(1*(size(obj,3)/2)*prop_phs*psz);

for zIdx = 1:length(Focus_range)
    back_prop(:,:,zIdx)     = ifft2(back_prop(:,:,zIdx).* prop_kernel);
end

prop_kernel             = conj(exp(1*prop_phs*psz));

% compute gradient at each slice and update the object
obj_update = single(zeros(size(obj,1),size(obj,2),size(obj,3)));

if use_gpu
    obj_update = gpuArray(obj_update);
    back_prop = gpuArray(back_prop);
end

for k = 1:length(Focus_range)

    back_prop_temp = back_prop(:,:,k);

    for layerIdx = size(obj,3):-1:1
        grad                = conj(efield_vol(:,:,layerIdx)).* back_prop_temp;
        transmission_layer  = conj(exp(1i*2*pi*obj(:,:,layerIdx)*psz/lambda*OF));
        grad                = transmission_layer.* grad;
        grad                = (-1i*2*pi*psz/lambda) * grad;
        obj_update(:,:,layerIdx)   = obj_update(:,:,layerIdx) - step_size * grad;

        back_prop_temp           = transmission_layer.* back_prop_temp;
        if layerIdx>1
            back_prop_temp       = ifft2(prop_kernel.* fft2(back_prop_temp));
        end
    end
end

obj = obj+obj_update./length(Focus_range);

end